# KATZ Brand Kit — draft v2

KATZ — Königsberger Allgemeine Technologie Zeitung (Koenigsberg General Technology Newspaper). Official newspaper of the Virtual City of Königsberg, published every Tuesday by the Königsberger Bridges Institute (KBI) at katz.news.

Status: draft for review. Not yet final.

## 1. The logo

The logo is a lockup of three lines, always in this order:

1. **KATZ** in Orbitron Black, spread so it is exactly as wide as line 2.
2. **Königsberger Allgemeine Technologie Zeitung** in Fraktur (UnifrakturMaguntia).
3. **Koenigsberg General Technology Newspaper** in Orbitron Regular, centred and lighter.

All logo files are outlined (text converted to shapes), so they need no fonts installed.

| File | Use |
| --- | --- |
| `katz-lockup-*` | Default. Website header, documents, slides, print. |
| `katz-lockup-compact-*` | Lines 1 and 2 only, where the English line would be too small to read. |
| `katz-wordmark-*` | KATZ alone, for tight spaces (bylines, watermarks, small badges). |
| `katz-monogram` | The K on Prussian blue. Favicon and app icon only. |
| `-ink` / `-paper` / `-prussian` | Transparent background, coloured logo. Use paper on dark backgrounds. |
| `-on-paper` / `-on-prussian` | Logo on its own solid background, ready to drop in. |

**Clear space:** keep empty space around the lockup at least as tall as the Fraktur line.

**Minimum sizes:** full lockup 240 px (40 mm) wide; compact lockup 160 px (28 mm); wordmark 80 px (15 mm). Below 64 px, use the monogram.

**Don't:**
- Stretch, squash, rotate or add effects (shadows, glows, outlines).
- Set KATZ in Fraktur, or the German name in Orbitron. The pairing is the identity.
- Change the order of the lines, or the width lock between lines 1 and 2.
- Recolour outside the palette below.
- Use cat imagery or memes with the official logo. The informal social brand stays separate.

## 2. Colours

| Name | Hex | RGB | Use |
| --- | --- | --- | --- |
| Ink | #111418 | 17, 20, 24 | Logo, headlines, body text |
| Paper | #F4F0E6 | 244, 240, 230 | Page background |
| Prussian Blue | #003153 | 0, 49, 83 | Brand accent: section labels, links, monogram |
| Graphite | #3A3F45 | 58, 63, 69 | Secondary text, data lines |
| Slate | #5B6067 | 91, 96, 103 | English subtitle, captions |
| Signal Cyan | #6CD6FF | 108, 214, 255 | Digital accent on dark backgrounds only |
| Gold | #EEC464 | 238, 196, 100 | Rare highlight, shared with KBI |

Ink on Paper and Paper on Prussian Blue both meet WCAG AA contrast for text. Never put Signal Cyan or Gold text on Paper: the contrast is too low.

## 3. Typography

| Font | Role | Licence |
| --- | --- | --- |
| Orbitron (Black 900, Regular 400) | KATZ wordmark; English subtitle | SIL Open Font License |
| UnifrakturMaguntia | The German name only | SIL Open Font License |
| Barlow (Regular, SemiBold) | Short interface and ear text | SIL Open Font License |
| IBM Plex Mono (Regular, Medium) | Masthead rails, dates, labels, data | SIL Open Font License |

All four are free on Google Fonts and included in `fonts/` with their licences. Fraktur is for the masthead name only — never for headlines or body text. The article body typeface is still to be chosen (open item).

## 4. Masthead

`masthead/editions/` holds a ready masthead for every edition from Nr. 001 (Tue 26 Aug 2025) to Nr. 067 (Tue 1 Dec 2026), as SVG and PNG. `masthead/katz-masthead-sample` is the launch edition, Nr. 064. Fixed text:

- Top rail: `NR. [edition] · JAHRGANG [year]` · `54°42′23.0″N · 20°30′42.0″E · VIRTUELLE STADT KÖNIGSBERG` · `KATZ.NEWS`
- Left ear: `GEGRÜNDET 2025` · Official newspaper of the Virtual City of Königsberg
- Right ear: `KOSTENLOS` · Erscheint jeden Dienstag · Free · Published every Tuesday
- Bottom rail: `[weekday, date]` · the four sections · `AUSGABE [edition]`

Update the edition number, year (Jahrgang) and date each Tuesday. Jahrgang changes every 26 August.

## 5. Favicon

Copy everything in `favicon/` to the site root and paste `head-snippet.html` into each page's `<head>`. Includes ICO (16/32/48), SVG, Apple touch icon (180), 192, 512, maskable 512 and `site.webmanifest`.

## 6. Social banners

All on Paper, in the masthead style. Sizes as listed in each file name.

| File | Note |
| --- | --- |
| `og-share-1200x630` | Default link preview for katz.news |
| `linkedin-company-cover-1128x191` | Company page; content kept clear of the logo overlap |
| `linkedin-personal-banner-1584x396` | Personal profiles; content kept right, clear of the profile photo |
| `x-header-1500x500` | Profile photo covers the lower left |
| `facebook-cover-1640x624` | Content centred for mobile cropping |
| `youtube-banner-2560x1440` | Content inside the 1546 x 423 safe area |
| `profile-1080-monogram` / `profile-1080-wordmark` | Profile pictures |

## 7. Open items

1. Trademark check for "KATZ" and the full German name before print.
2. Choose the article body typeface.
3. Confirm the monogram (K with cyan underline) as the favicon.
